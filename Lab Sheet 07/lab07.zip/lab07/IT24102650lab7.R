setwd("C:\\Users\\User\\Desktop\\lab07")

#Q1:Uniform Distribution
prob_interval <- punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Q2:Exponential Distribution
#lambda parameter
lambda <- 1/3
probability <- pexp(2, rate = lambda, lower.tail = TRUE)

#Q3: part1:Normal Distribution
#standard deviation
mu <- 100
sigma <- 15#

prob_above_130 <- 1 - pnorm(130, mean = mu, sd = sigma)

#Q3: part2 :Normal distribution
percentile_95 <- qnorm(0.95, mean = mu, sd = sigma)
