setwd("C:\\Users\\it24102650\\Desktop\\IT24102650")
branch_data <- read.csv("Exercise.txt",header =TRUE)
head(branch_data)
sapply(branch_data,class)

boxplot(branch_data$Sales_X1,
        main = "boxplot of sales",
        ylab = "sales",
        col ="lightblue")

print(fivenum(branch_data$Advertising_X2))
IQR(branch_data$Advertising_X2)

find_outliers <- function(x){
  Q1 <- quantile(x,0.25)
  Q3 <-quantile(x,0.75)
  IQR_val <- Q3- Q1
  lower_bound <- Q1-1.5*IQR_val
  upper_bound <- Q3 + 1.5*IQR_val
  outliers <- x[x <lower_bound | x> upper_bound]
  return(outliers)
}

yers_outliers <- find_outliers(branch_data$Years_X3)

cat("outliers in 'Years_X3' variable:\n")
if(length(years_outliers) == 0){
  cat("No outliers found.\n")
} else
  {
  print(years_outliers)
}
  

  
